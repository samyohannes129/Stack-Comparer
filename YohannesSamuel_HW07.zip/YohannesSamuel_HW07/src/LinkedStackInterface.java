/**
 * Description: Interface that imports properties to be used as getters and setters
 * 
 * @author Samuel Yohannes
 * @contact mi8854we@go.minnstate.edu
 * @since 10/25/23
 * 
 * Institution: Century College
 *  Professor: Matthew Nyamagwa
 * 
 */
public interface LinkedStackInterface {
	public int size();
	public int pop();
	public void push(int element);
	public int peek();
	public boolean isEmpty();

}


