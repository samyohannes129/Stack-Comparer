/**
 * Description: Program creates 2 stacks and determines whether they are are identical or not
 * 
 * Input: 2 stacks
 * 
 * Output: Whether stacks are equal or not
 * 
 * @author Samuel Yohannes
 * @contact mi8854we@go.minnstate.edu
 * @since 10/25/23
 * 
 * Institution: Century College
 *  Professor: Matthew Nyamagwa
 * 
 */
import java.util.EmptyStackException;
public class driver {
	public static void main(String[] args) {
		
		//Creates 2 new stacks
		IntLinkedStack intStack1 = new IntLinkedStack();
		IntLinkedStack intStack2 = new IntLinkedStack();
		int[] array = {21, 14, 19, 43, 58, 78, 77, 93, 95, 58};

		
		//PUSHES array into stack
		for(int i = 0; i < array.length; i++)
			intStack1.push(array[i]);
		for(int i = 0; i < array.length; i++)
			intStack2.push(array[i]);
		
		// try and catch block to catch exceptions while popping nodes in stack 1
		try {
		System.out.println("Popped: " + intStack1.pop());
		//Popping twice
		System.out.println("Popped: " + intStack1.pop());
		} catch(EmptyStackException ex) {
			System.out.println(ex);
		}catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println(ex);
		}catch (Exception ex) {
			System.out.println(ex);
		}
		
		//pushing vlaues and printing them with the size
		intStack1.push(99);
		intStack1.push(999);
		System.out.println("Stack: " + intStack1.toString(intStack1));
		System.out.println("Size: " + intStack1.size());
		
		// try and catch block to catch exceptions while popping nodes in stack 2
		try {
		System.out.println("Popped: " + intStack2.pop());
		System.out.println("Popped: " + intStack2.pop());
		} catch(EmptyStackException ex) {
			System.out.println(ex);
		}catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println(ex);
		}catch (Exception ex) {
			System.out.println(ex);
		}
		
		//pushing values and printing them with the size
		intStack2.push(99);
		intStack2.push(999);
		System.out.println("Stack: " + intStack2.toString(intStack2));
		System.out.println("Size: " + intStack2.size());
		
		//outputs whether the stacks are identical or not
		System.out.println("Stacks are identical: " + compareStacks(intStack1, intStack2));
    
	}

	/**
	 * 
	 * Compares if Stacks are identical or not
	 * @param LinkedStack stack1
	 * @param LinkedStack stack2
	 * @return true or false
	 */
	private static boolean compareStacks(IntLinkedStack stack1, IntLinkedStack stack2) {
	        if (stack1.size() != stack2.size()) {
	            return false;
	        }
	        while (!stack1.isEmpty()) {
	            if (stack1.pop()!=stack2.pop()) {
	                return false;
	            }
	        }
		return true;
	}
}
