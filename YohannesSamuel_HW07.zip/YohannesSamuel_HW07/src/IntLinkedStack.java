/**
 * Description: Program implements LinkedStackInterface and creates getters and setters for the properties
 * 
 * @author Samuel Yohannes
 * @contact mi8854we@go.minnstate.edu
 * @since 10/25/23
 * 
 * Institution: Century College
 *  Professor: Matthew Nyamagwa
 * 
 */
import java.util.EmptyStackException;
public class IntLinkedStack implements LinkedStackInterface {
	
	//PROPERTIES
	private IntNode top;
	
	// CONSTRUCTOR
	
	//NO ARGUMENT CONSTRUCTOR
	/**
	 * Set initial array capacity to 10.
	 */
	public IntLinkedStack() {
		this.top = null;
	}

	
	@Override
	/**
	 * Gets Size of the Stack
	 */
	public int size() {
		return IntNode.listLength(this.top);
	}

	@Override
	/**
	 * Remove element from top of the stack
	 */
	public int pop() {
		if(isEmpty())
			throw new EmptyStackException();
		int data = this.top.getData();
		this.top = top.getLink();
		return data;
	}

	@Override
	/**
	 * add an element from the top of the stack
	 */
	public void push(int element) {
		this.top = new IntNode(element, top);
		
	}

	@Override
	/**
	 * Checks element at the top without removing 
	 * @return data
	 */
	public int peek() {
		if(isEmpty())
			throw new EmptyStackException();
		int data = this.top.getData();
		return data;
	}

	@Override
	/**
	 * Checks whether the stack is empty or not
	 */
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.top==null;
	}


	/**
	 * Returns visual representation of stack
	 */
	public String toString(IntLinkedStack head) {
		IntNode cursor;
		
		String list = "Head --> | ";
		for(cursor = this.top; cursor != null; cursor = cursor.link ) {
			list = list + cursor.getData() + " | --> | ";
		}
		list = list + "NULL";
		
		return list;
	}


}
